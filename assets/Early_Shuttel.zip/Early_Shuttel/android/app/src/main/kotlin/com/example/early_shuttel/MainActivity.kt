package com.example.early_shuttel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
