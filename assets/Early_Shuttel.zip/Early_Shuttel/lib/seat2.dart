import 'package:flutter/material.dart';

class seat2 extends StatefulWidget {
  const seat2({Key? key}) : super(key: key);

  @override
  State<seat2> createState() => _seatState2();
}

class _seatState2 extends State<seat2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff13ccae),
        title: Text('Route'),
      ),
      body: SingleChildScrollView(
        child: Column(
            children: [
              SizedBox(height: 100,),
        Card(
          elevation:20,
          child: Container(
            height: 460,
            width: MediaQuery.of(context).size.width*0.99,
            color: Colors.white,
            child: Column(
              children: [
                SizedBox(height: 10,),
                Row(
                  children: [
                    Text('   Route 32-Dwarka Mor-Sector 56 \n   Golf Course Road',style: TextStyle(fontSize: 15,color: Colors.grey),),
                    SizedBox(width: 50,),
                    Image.asset('assets/map2.png',height: 25,)
                  ],
                ),
                SizedBox(height: 20,),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        children: [
                          Image.asset('assets/circle.png',height: 20,),
                          Text('|',style: TextStyle(fontSize: 35),),
                          Image.asset('assets/mapicon1.png',height: 25,)
                        ],
                      ),
                    ),
                    Column(
                      children: [
                        Row(
                          children: [
                            Text('Sector-21 Metro Station \n (gate No.2)Dwarka',style: TextStyle(fontSize: 16),),
                            SizedBox(width: 35,),
                            Image.asset('assets/bus5.png',height: 20,),
                            SizedBox(width: 10,),
                            Text('Distance \n  0.18 km',style: TextStyle(fontSize: 13),)
                          ],
                        ),
                        Divider(thickness: 2,color: Colors.black,),
                        Row(
                          children: [
                            Text('Rohini Vihar East Metro \n Station',style: TextStyle(fontSize: 16),),
                            SizedBox(width: 25,),
                            Image.asset('assets/bus5.png',height: 20,),
                            SizedBox(width: 10,),
                            Text('Distance \n  0.78 km',style: TextStyle(fontSize: 13),)
                          ],
                        )
                      ],
                    )
                  ],
                ),
                        SizedBox(height: 30,),
                        Container(
                          height: 220,
                          width: 300,
                          color: Colors.white,
                          child: Column(
                            children: [
                              SizedBox(height: 20,),
                              Row(
                                children: [
                                  Container(
                                    height: 30,
                                    width: 80,
                                    color: Color(0xffFFEBCD),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text('11:15 AM',style: TextStyle(fontSize: 14),),
                                    ),
                                  ),
                                  SizedBox(width: 20,),
                                  Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                  Text('12 Avail'),
                                  SizedBox(width: 20,),
                                  Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                  Text('30 Total')
                                ],
                              ),
                              SizedBox(height: 20,),
                              Row(
                                children: [
                                  Container(
                                    height: 30,
                                    width: 80,
                                    color: Color(0xffFFEBCD),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text('02:40 PM',style: TextStyle(fontSize: 14),),
                                    ),
                                  ),
                                  SizedBox(width: 20,),
                                  Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                  Text('30 Avail'),
                                  SizedBox(width: 20,),
                                  Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                  Text('50 Total')
                                ],
                              ),
                              SizedBox(height: 20,),
                              Row(
                                children: [
                                  Container(
                                    height: 30,
                                    width: 80,
                                    color: Color(0xffFFEBCD),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text('03:30 PM',style: TextStyle(fontSize: 14),),
                                    ),
                                  ),
                                  SizedBox(width: 20,),
                                  Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                  Text('22 Avail'),
                                  SizedBox(width: 20,),
                                  Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                  Text('30 Total')
                                ],
                              ),
                              SizedBox(height: 20,),
                              Row(
                                children: [
                                  Container(
                                    height: 30,
                                    width: 80,
                                    color: Color(0xffFFEBCD),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text('05:00 PM',style: TextStyle(fontSize: 14),),
                                    ),
                                  ),
                                  SizedBox(width: 20,),
                                  Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                  Text('16 Avail'),
                                  SizedBox(width: 20,),
                                  Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                  Text('25 Total')
                                ],
                              ),
                            ],
                          ),
                        )

                      ],
                    ),
                  ),
        ),
            ]
        ),),);
  }
}
