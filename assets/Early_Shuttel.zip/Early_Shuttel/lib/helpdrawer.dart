import 'package:flutter/material.dart';

class help1 extends StatefulWidget {
  const help1({Key? key}) : super(key: key);

  @override
  State<help1> createState() => _help1State();
}

class _help1State extends State<help1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff13ccae),
        title: Text('Help'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 40,),

            Text('1. Know and target your customers right Every customer is different so you need to find specifics customer characteristics\n and make content that is targeted to your audience. \n Remember that you can not appeal to everyone because you will never be able to meet everybody’s \n needs at once. You can look at your current customer base and choose specific demographics and psychographics to target.\n Think about customer age, location, education level, occupation, gender, values, personality, behavior, interests.\n Market research and proper targeting of the market can take some time, \n but always keep in mind that this is a higher goal in the future'),
            SizedBox(height: 10,),
            Text('2. Know and target your customers right Every customer is different so you need to find specifics customer characteristics\n and make content that is targeted to your audience. \n Remember that you can not appeal to everyone because you will never be able to meet everybody’s \n needs at once. You can look at your current customer base and choose specific demographics and psychographics to target.\n Think about customer age, location, education level, occupation, gender, values, personality, behavior, interests.')
          ],
        ),
      ),
    );
  }
}
