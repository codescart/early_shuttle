import 'package:flutter/material.dart';

class page3 extends StatefulWidget {
  const page3({Key? key}) : super(key: key);

  @override
  State<page3> createState() => _page3State();
}

class _page3State extends State<page3> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Color(0xff13ccae),
        title: Text('Routes'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [

            Padding(
              padding: const EdgeInsets.fromLTRB(0, 50, 0, 0),
              child: Text('Delhi Route Map',style: TextStyle(color: Colors.black,fontSize: 20,decoration: TextDecoration.underline,fontWeight: FontWeight.bold),),
            ),
            SizedBox(height: 120,),
            Image.asset('assets/roadimg.jpg',height: 360,)
          ],
        ),
      ),
    );
  }
}
