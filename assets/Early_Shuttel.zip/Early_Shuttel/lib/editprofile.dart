import 'package:early_shuttel/homepage.dart';
import 'package:early_shuttel/train.dart';
import 'package:flutter/material.dart';

class editprofile extends StatefulWidget {
  const editprofile({Key? key}) : super(key: key);

  @override
  State<editprofile> createState() => _editprofileState();
}

class _editprofileState extends State<editprofile> {
  get floatingActionButton => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Color(0xff13ccae),
        title: Text('Edit Details',style: TextStyle(fontSize: 19),
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 100, 0, 0),
                child: Container(
                  height: 375,
                  width: 350,
                  color: Colors.white,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: CircleAvatar(
                          backgroundColor: Color(0xff13ccae),
                          radius: 40,
                          child: Icon(Icons.person,size: 40,color: Colors.black,),
                        ),
                      ),
                      SizedBox(height: 0,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(

                            width:50,
                              child: Text('Name:',style: TextStyle(fontSize: 16,color: Color(0xff13ccae),),)
                          ),
                          SizedBox(width: 10,),
                          Container(
                              width:200,
                              child: TextField()
                          ),
                        ],
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                              width:50,
                              child: Text('Email:',style: TextStyle(fontSize: 16,color: Color(0xff13ccae),),),
                          ),
                          SizedBox(width: 10,),
                          Container(
                              width:200,
                              child: TextField()
                          ),
                        ],
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                              width:50,
                              child: Text('Phone:',style: TextStyle(fontSize: 16,color: Color(0xff13ccae),),)
                          ),
                          SizedBox(width: 10,),
                          Container(
                              width:200,
                              child: TextField()
                          ),
                        ],
                      ),
                      SizedBox(height: 20,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width:50,
                            child: Text('Location:',style: TextStyle(fontSize: 12,color: Color(0xff13ccae),),),
                          ),
                          SizedBox(width: 10,),
                          Container(
                              width:200,
                              child: TextField()
                          ),
                        ],
                      ),

                    ],
                  )
                  )
                ),
              Container(
                child: ElevatedButton(
                    onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (context) => homepage()),);
                    },
                    style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.all(0),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    child: Ink(
                        decoration: BoxDecoration(
                          //   //
                          // color: Colors.black,

                            gradient: const LinearGradient(
                                colors: [Color(0xff34445e), Color(0xff00aeb8)]),
                            borderRadius: BorderRadius.circular(10)),

                        child: Container(
                            width: 290,
                            height: 40,
                            alignment: Alignment.center,
                            child: const Text(
                              'Save Changes',style: TextStyle(fontSize: 15),
                            )))),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
