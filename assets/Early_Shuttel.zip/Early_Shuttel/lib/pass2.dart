import 'package:early_shuttel/seat1.dart';
import 'package:flutter/material.dart';

class pass2 extends StatefulWidget {
  const pass2({Key? key}) : super(key: key);

  @override
  State<pass2> createState() => _pass2State();
}

class _pass2State extends State<pass2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff13ccae),
        title: Text('Select Route'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 40,),
            GestureDetector(
              onTap: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>seat1()));},
              child:Card(
                elevation:20,
                child:
                Container(
                  height: 120,
                  width: MediaQuery.of(context).size.width*0.99,
                  color: Colors.white,
                  child: Column(
                    children: [
                      SizedBox(height: 20,),
                      Text('Route:1 -'),
                      Text('___________________'),
                      Text('bbhfudhjvnj')
                         
                    ],
                  ),
                ),
              ),),
          ],
        ),
      ),
    );
  }
}
