import 'package:early_shuttel/seat1.dart';
import 'package:early_shuttel/seat2.dart';
import 'package:early_shuttel/seat3.dart';
import 'package:early_shuttel/seat4.dart';
import 'package:flutter/material.dart';

class train extends StatefulWidget {
  const train({Key? key}) : super(key: key);

  @override
  State<train> createState() => _trainState();
}

class _trainState extends State<train> {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Color(0XFFF8F8FF),
      appBar: AppBar(
        elevation: 20,
        foregroundColor: Colors.black,
        backgroundColor: Colors.white,

        title: Text('Select the Route',style: TextStyle(color: Colors.black),),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            GestureDetector(
              onTap: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>seat1()));},
          child:Card(
          elevation:20,
          child:
            Container(
              height: 190,
              width: MediaQuery.of(context).size.width*0.99,
              color: Colors.white,
              child: Column(
                children: [
                  SizedBox(height: 10,),
                  Row(
                    children: [
                      Text('   Route 50-Sohna Road-Paschim Vihar',style: TextStyle(fontSize: 15,color: Colors.grey),),
                      SizedBox(width: 50,),
                      Image.asset('assets/map2.png',height: 25,)
                    ],
                  ),
                  SizedBox(height: 20,),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          children: [
                            Image.asset('assets/circle.png',height: 20,),
                            Text('|',style: TextStyle(fontSize: 35),),
                            Image.asset('assets/mapicon1.png',height: 25,)
                          ],
                        ),
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Text('Sector-21 Metro Station \n (gate No.2)Dwarka',style: TextStyle(fontSize: 16),),
                              SizedBox(width: 35,),
                              Image.asset('assets/bus5.png',height: 20,),
                              SizedBox(width: 10,),
                              Text('Distance \n  0.08 km',style: TextStyle(fontSize: 13),)
                            ],
                          ),
                          Divider(thickness: 2,color: Colors.black,),
                          Row(
                            children: [
                              Text('Paschim Vihar East Metro \n Station',style: TextStyle(fontSize: 16),),
                              SizedBox(width: 25,),
                              Image.asset('assets/bus5.png',height: 20,),
                              SizedBox(width: 10,),
                              Text('Distance \n  0.08 km',style: TextStyle(fontSize: 13),)
                            ],
                          )
                        ],
                      )
                    ],
                  ),
                ],
              ),
            ),
          ),),

            // 2nd container
            SizedBox(height: 8,),
            GestureDetector(
              onTap: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>seat2()));},
              child:Card(
                elevation:20,
              child: Container(
                height: 190,
                width: MediaQuery.of(context).size.width*0.99,
                color: Colors.white,
                child: Column(
                  children: [
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        Text('   Route 32-Dwarka Mor-Sector 56 \n   Golf Course Road',style: TextStyle(fontSize: 15,color: Colors.grey),),
                        SizedBox(width: 50,),
                        Image.asset('assets/map2.png',height: 25,)
                      ],
                    ),
                    SizedBox(height: 20,),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Column(
                            children: [
                              Image.asset('assets/circle.png',height: 20,),
                              Text('|',style: TextStyle(fontSize: 35),),
                              Image.asset('assets/mapicon1.png',height: 25,)
                            ],
                          ),
                        ),
                        Column(
                          children: [
                            Row(
                              children: [
                                Text('Sector-21 Metro Station \n (gate No.2)Dwarka',style: TextStyle(fontSize: 16),),
                                SizedBox(width: 35,),
                                Image.asset('assets/bus5.png',height: 20,),
                                SizedBox(width: 10,),
                                Text('Distance \n  0.18 km',style: TextStyle(fontSize: 13),)
                              ],
                            ),
                            Divider(thickness: 2,color: Colors.black,),
                            Row(
                              children: [
                                Text('Rohini Vihar East Metro \n Station',style: TextStyle(fontSize: 16),),
                                SizedBox(width: 25,),
                                Image.asset('assets/bus5.png',height: 20,),
                                SizedBox(width: 10,),
                                Text('Distance \n  0.78 km',style: TextStyle(fontSize: 13),)
                              ],
                            )
                          ],
                        )
                      ],
                    ),

                  ],
                ),
              ),
            ),),

            //3rd Container
            SizedBox(height: 10,),
            GestureDetector(
              onTap: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>seat3()));},
              child:Card(
                elevation:20,
              child: Container(
                height: 190,
                width: MediaQuery.of(context).size.width*0.99,
                color: Color(0xfffefefe),
                child: Column(
                  children: [
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        Text('   Route 12-gurugram Road-Haryana Road',style: TextStyle(fontSize: 15,color: Colors.grey),),
                        SizedBox(width: 50,),
                        Image.asset('assets/map2.png',height: 20,)
                      ],
                    ),
                    SizedBox(height: 20,),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Column(
                            children: [
                              Image.asset('assets/circle.png',height: 20,),
                              Text('|',style: TextStyle(fontSize: 35),),
                              Image.asset('assets/mapicon1.png',height: 25,)
                            ],
                          ),
                        ),
                        Column(
                          children: [
                            Row(
                              children: [
                                Text('Sector-11 Metro Station \n (gate No.2)Gurugram',style: TextStyle(fontSize: 16),),
                                SizedBox(width: 35,),
                                Image.asset('assets/bus5.png',height: 20,),
                                SizedBox(width: 10,),
                                Text('Distance \n  12.08 km',style: TextStyle(fontSize: 13),)
                              ],
                            ),
                            Divider(thickness: 2,color: Colors.black,),
                            Row(
                              children: [
                                Text('Haryana Vihar East Metro \n Station',style: TextStyle(fontSize: 16),),
                                SizedBox(width: 25,),
                                Image.asset('assets/bus5.png',height: 20,),
                                SizedBox(width: 10,),
                                Text('Distance \n  6.18 km',style: TextStyle(fontSize: 13),)
                              ],
                            )
                          ],
                        )
                      ],
                    ),

                  ],
                ),
              ),
            ),),
            //4th container
            SizedBox(height: 8,),
            GestureDetector(
              onTap: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>seat4()));},
              child:Card(
                elevation:20,
              child: Container(
                height: 190,
                width: MediaQuery.of(context).size.width*0.99,
                color: Colors.white,
                child: Column(
                  children: [
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        Text('   Route 24-Delhi Road-New Delhi Vihar',style: TextStyle(fontSize: 15,color: Colors.grey),),
                        SizedBox(width: 50,),
                        Image.asset('assets/map2.png',height: 25,)
                      ],
                    ),
                    SizedBox(height: 20,),
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Column(
                            children: [
                              Image.asset('assets/circle.png',height: 20,),
                              Text('|',style: TextStyle(fontSize: 35),),
                              Image.asset('assets/mapicon1.png',height: 25,)
                            ],
                          ),
                        ),
                        Column(
                          children: [
                            Row(
                              children: [
                                Text('Sector-21 Metro Station \n (gate No.2)Dwarka',style: TextStyle(fontSize: 16),),
                                SizedBox(width: 35,),
                                Image.asset('assets/bus5.png',height: 20,),
                                SizedBox(width: 10,),
                                Text('Distance \n  7.68 km',style: TextStyle(fontSize: 13),)
                              ],
                            ),
                            Divider(thickness: 2,color: Colors.black,),
                            Row(
                              children: [
                                Text('New Delhi  Vihar  Metro \n Station',style: TextStyle(fontSize: 16),),
                                SizedBox(width: 25,),
                                Image.asset('assets/bus5.png',height: 20,),
                                SizedBox(width: 10,),
                                Text('Distance \n  23.08 km',style: TextStyle(fontSize: 13),)
                              ],
                            )
                          ],
                        )
                      ],
                    ),

                  ],
                ),
              ),
            ),),
            SizedBox(height: 20,)

          ],
        ),
      ),
    );
  }
}
