import 'package:flutter/material.dart';

class notify extends StatefulWidget {
  const notify({Key? key}) : super(key: key);

  @override
  State<notify> createState() => _notifyState();
}

class _notifyState extends State<notify> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Color(0xff13ccae),
        title: Text('Notification',style: TextStyle(fontSize: 19),
        ),
      ),
      body: Center(
        child: Column(
          children:[
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 330, 0, 0),
              child: Text('You don`t have any notifications right now',style: TextStyle(color: Colors.grey),),
            )
            
          ],
        ),
      ),
    );
  }
}
