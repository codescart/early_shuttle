import 'package:flutter/material.dart';

class seat4 extends StatefulWidget {
  const seat4({Key? key}) : super(key: key);

  @override
  State<seat4> createState() => _seat4State();
}

class _seat4State extends State<seat4> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff13ccae),
        title: Text('Route'),
      ),
      body: SingleChildScrollView(
        child: Column(
            children: [
              SizedBox(height: 100,),
              Card(
                elevation:20,
                child:
                Container(
                  height: 460,
                  width: MediaQuery.of(context).size.width*0.99,
                  color: Colors.white,
                  child: Column(
                    children: [
                      SizedBox(height: 10,),
                      Row(
                        children: [
                          Text('   Route 24-Delhi Road-New Delhi Vihar',style: TextStyle(fontSize: 15,color: Colors.grey),),
                          SizedBox(width: 50,),
                          Image.asset('assets/map2.png',height: 25,)
                        ],
                      ),
                      SizedBox(height: 20,),
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Column(
                              children: [
                                Image.asset('assets/circle.png',height: 20,),
                                Text('|',style: TextStyle(fontSize: 35),),
                                Image.asset('assets/mapicon1.png',height: 25,)
                              ],
                            ),
                          ),
                          Column(
                            children: [
                              Row(
                                children: [
                                  Text('Sector-21 Metro Station \n (gate No.2)Dwarka',style: TextStyle(fontSize: 16),),
                                  SizedBox(width: 35,),
                                  Image.asset('assets/bus5.png',height: 20,),
                                  SizedBox(width: 10,),
                                  Text('Distance \n  7.68 km',style: TextStyle(fontSize: 13),)
                                ],
                              ),
                              Divider(thickness: 2,color: Colors.black,),
                              Row(
                                children: [
                                  Text('New Delhi  Vihar  Metro \n Station',style: TextStyle(fontSize: 16),),
                                  SizedBox(width: 25,),
                                  Image.asset('assets/bus5.png',height: 20,),
                                  SizedBox(width: 10,),
                                  Text('Distance \n  23.08 km',style: TextStyle(fontSize: 13),)
                                ],
                              )
                            ],
                          )
                        ],
                      ),
                      SizedBox(height: 30,),
                      Container(
                        height: 220,
                        width: 300,
                        color: Colors.white,
                        child: Column(
                          children: [
                            SizedBox(height: 20,),
                            Row(
                              children: [
                                Container(
                                  height: 30,
                                  width: 80,
                                  color: Color(0xffFFEBCD),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text('06:00 AM',style: TextStyle(fontSize: 14),),
                                  ),
                                ),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                Text('12 Avail'),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                Text('30 Total')
                              ],
                            ),
                            SizedBox(height: 20,),
                            Row(
                              children: [
                                Container(
                                  height: 30,
                                  width: 80,
                                  color: Color(0xffFFEBCD),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text('07:00 AM',style: TextStyle(fontSize: 14),),
                                  ),
                                ),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                Text('30 Avail'),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                Text('50 Total')
                              ],
                            ),
                            SizedBox(height: 20,),
                            Row(
                              children: [
                                Container(
                                  height: 30,
                                  width: 80,
                                  color: Color(0xffFFEBCD),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text('08:00AM',style: TextStyle(fontSize: 14),),
                                  ),
                                ),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                Text('22 Avail'),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                Text('30 Total')
                              ],
                            ),
                            SizedBox(height: 20,),
                            Row(
                              children: [
                                Container(
                                  height: 30,
                                  width: 80,
                                  color: Color(0xffFFEBCD),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text('10:00 AM',style: TextStyle(fontSize: 14),),
                                  ),
                                ),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                Text('16 Avail'),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                Text('25 Total')
                              ],
                            ),
                          ],
                        ),
                      )

                    ],
                  ),
                ),
              )
            ]
        ),),
    );
  }
}
