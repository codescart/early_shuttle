import 'package:flutter/material.dart';

class seat3 extends StatefulWidget {
  const seat3({Key? key}) : super(key: key);

  @override
  State<seat3> createState() => _seat3State();
}

class _seat3State extends State<seat3> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Color(0xff13ccae),
        title: Text('Route'),

      ),
      body: SingleChildScrollView(
        child: Column(
            children: [
              SizedBox(height: 100,),
              Card(
                elevation:40,
                child:
                Container(
                  height: 460,
                  width: MediaQuery.of(context).size.width*0.99,
                  color: Color(0xfffefefe),
                  child: Column(
                    children: [
                      SizedBox(height: 10,),
                      Row(
                        children: [
                          Text('   Route 12-gurugram Road-Haryana Road',style: TextStyle(fontSize: 15,color: Colors.grey),),
                          SizedBox(width: 50,),
                          Image.asset('assets/map2.png',height: 20,)
                        ],
                      ),
                      SizedBox(height: 20,),
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Column(
                              children: [
                                Image.asset('assets/circle.png',height: 20,),
                                Text('|',style: TextStyle(fontSize: 35),),
                                Image.asset('assets/mapicon1.png',height: 25,)
                              ],
                            ),
                          ),
                          Column(
                            children: [
                              Row(
                                children: [
                                  Text('Sector-11 Metro Station \n (gate No.2)Gurugram',style: TextStyle(fontSize: 16),),
                                  SizedBox(width: 35,),
                                  Image.asset('assets/bus5.png',height: 20,),
                                  SizedBox(width: 10,),
                                  Text('Distance \n  12.08 km',style: TextStyle(fontSize: 13),)
                                ],
                              ),
                              Divider(thickness: 2,color: Colors.black,),
                              Row(
                                children: [
                                  Text('Haryana Vihar East Metro \n Station',style: TextStyle(fontSize: 16),),
                                  SizedBox(width: 25,),
                                  Image.asset('assets/bus5.png',height: 20,),
                                  SizedBox(width: 10,),
                                  Text('Distance \n  6.18 km',style: TextStyle(fontSize: 13),)
                                ],
                              )
                            ],
                          )
                        ],
                      ),
                      SizedBox(height: 30,),
                      Container(
                        height: 220,
                        width: 300,
                        color: Colors.white,
                        child: Column(
                          children: [
                            SizedBox(height: 20,),
                            Row(
                              children: [
                                Container(
                                  height: 30,
                                  width: 80,
                                  color: Color(0xffFFEBCD),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text('04:25 PM',style: TextStyle(fontSize: 14),),
                                  ),
                                ),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                Text('12 Avail'),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                Text('30 Total')
                              ],
                            ),
                            SizedBox(height: 20,),
                            Row(
                              children: [
                                Container(
                                  height: 30,
                                  width: 80,
                                  color: Color(0xffFFEBCD),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text('05:30 PM',style: TextStyle(fontSize: 14),),
                                  ),
                                ),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                Text('30 Avail'),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                Text('50 Total')
                              ],
                            ),
                            SizedBox(height: 20,),
                            Row(
                              children: [
                                Container(
                                  height: 30,
                                  width: 80,
                                  color: Color(0xffFFEBCD),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text('07:10 PM',style: TextStyle(fontSize: 14),),
                                  ),
                                ),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                Text('22 Avail'),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                Text('30 Total')
                              ],
                            ),
                            SizedBox(height: 20,),
                            Row(
                              children: [
                                Container(
                                  height: 30,
                                  width: 80,
                                  color: Color(0xffFFEBCD),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text('11:00 PM',style: TextStyle(fontSize: 14),),
                                  ),
                                ),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.greenAccent,size: 30,),
                                Text('16 Avail'),
                                SizedBox(width: 20,),
                                Icon(Icons.event_seat,color: Colors.red,size: 30,),
                                Text('25 Total')
                              ],
                            ),
                          ],
                        ),
                      )

                    ],
                  ),
                ),
              )
            ]
        ),),
    );
  }
}
