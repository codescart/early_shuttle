import 'dart:math';

import 'package:early_shuttle/User%20Interface/Constant%20Widgets/Container/Container_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../Constant/color.dart';

class CustomTextField extends StatelessWidget {
  final TextEditingController? controller;
  final InputDecoration? decoration = const InputDecoration();
  final TextStyle? style;
  final StrutStyle? strutStyle;
  final TextAlign textAlign = TextAlign.start;
  final TextAlignVertical? textAlignVertical;
  final TextDirection? textDirection;
  final bool readOnly = false;
  final int? maxLines = 1;
  final int? minLines;
  final bool expands = false;
  final int? maxLength;
  final bool obscureText = false;
  final TextInputType? keyboardType;
  final Widget? icon;
  final Color? iconColor;
  final String? label;
  final bool? filled;
  final Color? fillColor;
  final Color? focusColor;
  final Color? hoverColor;
  final void Function(String)? onChanged;
  final double? height;
  final double? width;
  final double? hintSize;
  final double? fontSize;
  final BoxBorder? border;
  final BorderRadiusGeometry? borderRadius;
  final List<BoxShadow>? boxShadow;
  final EdgeInsetsGeometry? contentPadding;
  final double? cursorHeight;
  final Color? cursorColor;
  final Widget? prefix;
  final Widget? sufix;

  CustomTextField({this.controller,
    this.style, this.strutStyle, this.textAlignVertical,
    this.textDirection, this.minLines, this.maxLength,
    this.keyboardType, this.icon, this.iconColor, this.label,
    this.filled, this.fillColor, this.focusColor, this.hoverColor, this.onChanged, this.height, this.width, this.hintSize, this.fontSize, this.border, this.borderRadius, this.boxShadow, this.contentPadding, this.cursorHeight, this.cursorColor, this.prefix, this.sufix
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height:height==null?50:height ,
      width:width==null?MediaQuery.of(context).size.width:width,
      decoration: BoxDecoration(
        border:border,
        borderRadius:borderRadius,
        boxShadow: boxShadow,
      ),
      child: TextField(
        controller: controller,
        cursorColor: cursorColor,
        cursorHeight: cursorHeight,
        onChanged: onChanged,
        maxLines: maxLines,
        maxLength: maxLength,
        expands: expands,
        readOnly: readOnly,
        obscureText: obscureText,
        keyboardType: keyboardType,
          style:style==null? GoogleFonts.alike(
            textStyle: TextStyle(
                fontSize:fontSize==null? 15:fontSize,
                fontWeight:FontWeight.normal,
                fontStyle: FontStyle.normal,
                color: ColorConstant.darkBlackColor
            ),
          ):style,
        decoration: InputDecoration(
          prefixIcon:prefix,
          suffixIcon: sufix,
          filled: filled==null? true:filled,
          fillColor: fillColor,
          hintText: label,
          hintStyle: GoogleFonts.alike(
            textStyle: TextStyle(
                fontSize:hintSize==null?15:hintSize,
                fontWeight:FontWeight.normal,
                fontStyle: FontStyle.normal,
                color: ColorConstant.greyColor
            ),
          ),
          // labelStyle: TextStyle(),
          contentPadding:contentPadding==null? EdgeInsets.only(left: 15, right: 15, top: 0, bottom: 0):contentPadding,
          border: OutlineInputBorder(
            borderSide: BorderSide.none
          )
        ),
      ),
    );
  }
}
